from flask import Flask,render_template

app = Flask(__name__)##we are using Flask class to instantiate the app

print(__name__)

# Root request
# anytime we hit slash (/) or what we call their root I want to define a function
#called hello world and return

@app.route('/')
def my_home():
    return render_template('index.html')

@app.route('/about.html')
def about():
    return render_template('about.html')

@app.route('/contact.html')
def contact():
    return render_template('contact.html')


@app.route('/professor.html')
def professor():
    return render_template('professor.html')

@app.route('/classes.html')
def classes():
    return render_template('classes.html')
